import urllib2

print urllib2.urlopen('http://www.google.com').read()
